'use client'
// Generated from Moru UI source. Do not edit. SPDX-License-Identifier: MIT
import { forwardRef, type TextareaHTMLAttributes } from 'react'
import { Field as BaseField } from '@base-ui/react/field'
import { cn } from './_lib/cn'
import { mergeDescriptionIds, useFieldContext } from './field-context'
import type { UIState } from './state'

export type TextareaProps = TextareaHTMLAttributes<HTMLTextAreaElement> & {
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
  previewState?: UIState
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  {
    className,
    size = 'md',
    id,
    'aria-describedby': describedBy,
    'aria-invalid': invalid,
    rows = 3,
    value,
    defaultValue,
    disabled,
    readOnly,
    name,
    loading = false,
    previewState,
    onChange,
    ...props
  },
  ref,
) {
  const field = useFieldContext()
  const busy = loading || previewState === 'loading'
  // Busy locks editing with readOnly, not disabled: the field keeps keyboard focus
  // and its value still takes part in form submission.
  const locked = disabled || previewState === 'disabled'
  const unavailable = locked || busy
  const textarea = (
    <textarea
      {...props}
      ref={ref}
      id={id ?? field?.controlId}
      rows={rows}
      aria-describedby={mergeDescriptionIds(describedBy, field?.describedBy)}
      aria-invalid={previewState === 'error' ? true : (invalid ?? (field?.invalid || undefined))}
      aria-busy={busy || undefined}
      className={cn('ui-textarea ui-field-focus w-full min-w-0', className)}
      data-size={size}
      data-ui-state={previewState}
      data-loading={busy || undefined}
      value={value}
      defaultValue={defaultValue}
      disabled={locked}
      readOnly={readOnly || busy}
      name={name}
      onChange={(event) => {
        if (!unavailable) onChange?.(event)
      }}
    />
  )

  const control = !field ? (
    textarea
  ) : (
    <BaseField.Control
      id={id ?? field.controlId}
      value={value}
      defaultValue={defaultValue}
      disabled={locked}
      name={name}
      render={textarea}
    />
  )
  return (
    <span className="ui-control-loading-wrap ui-textarea-loading-wrap" data-size={size}>
      {control}
      {busy && (
        <span className="ui-control-loading-indicator ui-loading-indicator" aria-hidden="true" />
      )}
    </span>
  )
})
