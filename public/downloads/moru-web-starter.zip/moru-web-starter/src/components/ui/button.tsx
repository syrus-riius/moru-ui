import { forwardRef, type ComponentPropsWithoutRef } from 'react'
import { Button as BaseButton } from '@base-ui/react/button'
import { cn } from '../../lib/cn'
import type { UIState } from './state'

export type ButtonProps = Omit<ComponentPropsWithoutRef<typeof BaseButton>, 'className'> & {
  className?: string
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger'
  size?: 'sm' | 'md' | 'lg'
  /** Allow a long action label to wrap while preserving the selected size's minimum height. */
  textWrap?: 'nowrap' | 'wrap'
  loading?: boolean
  previewState?: UIState
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    className,
    variant = 'primary',
    size = 'md',
    textWrap = 'nowrap',
    loading = false,
    disabled,
    children,
    previewState,
    onClick,
    ...props
  },
  ref,
) {
  const busy = loading || previewState === 'loading'
  const unavailable = disabled || busy || previewState === 'disabled'
  return (
    <BaseButton
      {...props}
      ref={ref}
      className={cn(
        'ui-button inline-flex items-center justify-center gap-2',
        textWrap === 'nowrap' && 'whitespace-nowrap',
        className,
      )}
      data-variant={previewState === 'error' ? 'danger' : variant}
      data-size={size}
      data-text-wrap={textWrap}
      data-ui-state={previewState}
      data-loading={busy || undefined}
      aria-busy={busy || undefined}
      disabled={unavailable}
      onClick={(event) => {
        if (!unavailable) onClick?.(event)
      }}
    >
      {busy && <span className="ui-button-spinner ui-loading-indicator" aria-hidden="true" />}
      {children}
    </BaseButton>
  )
})
